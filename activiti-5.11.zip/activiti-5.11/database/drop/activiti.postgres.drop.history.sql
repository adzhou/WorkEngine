drop table ACT_HI_PROCINST cascade;
drop table ACT_HI_ACTINST cascade;
drop table ACT_HI_VARINST cascade;
drop table ACT_HI_TASKINST cascade;
drop table ACT_HI_DETAIL cascade;
drop table ACT_HI_COMMENT cascade;
drop table ACT_HI_ATTACHMENT cascade;
